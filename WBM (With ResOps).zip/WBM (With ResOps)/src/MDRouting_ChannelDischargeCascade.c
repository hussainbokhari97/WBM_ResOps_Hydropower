/******************************************************************************

GHAAS Water Balance/Transport Model
Global Hydrological Archive and Analysis System
Copyright 1994-2023, UNH - ASRC/CUNY

MDRouting_ChannelDichargeCascade.c

bfekete@gc.cuny.edu

*******************************************************************************/

#include <MF.h>
#include <MD.h>

int MDRouting_ChannelDischargeCascadeDef () {
	return (CMfailed);
}
