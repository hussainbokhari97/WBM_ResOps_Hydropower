/******************************************************************************

GHAAS Water Balance/Transport Model
Global Hydrological Archive and Analysis System
Copyright 1994-2023, UNH - ASRC/CUNY

wbm.h

balazs.fekete@unh.edu

*******************************************************************************/

#include <stdio.h>

#include <cm.h>
#include <MF.h>
#include <MD.h>
